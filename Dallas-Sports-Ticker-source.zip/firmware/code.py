"""CircuitPython Pico W client for protocol v1. Install adafruit_requests.mpy.
Physical hardware verification required. No application OTA flash writes in v1.
"""
import os
import time
import gc
from array import array
import board
import digitalio
import displayio
import rgbmatrix
import wifi
import socketpool
import ssl
import adafruit_requests

WIDTH, HEIGHT = 192, 32
SIZE = WIDTH * HEIGHT * 2
URL = os.getenv('TICKER_URL', '').rstrip('/')
TOKEN = os.getenv('TICKER_DEVICE_TOKEN', '')
SSID = os.getenv('CIRCUITPY_WIFI_SSID', '')
PASSWORD = os.getenv('CIRCUITPY_WIFI_PASSWORD', '')
if not URL.startswith('https://') or not TOKEN or not SSID:
    raise RuntimeError('Set HTTPS URL, token and Wi-Fi in settings.toml')
displayio.release_displays()
# Native 16-bit buffer; RP2040 is little-endian. Incoming bytes are staged
# before applying, so a partial or oversized response never replaces a frame.
fb = array('H', [0] * (WIDTH * HEIGHT))
gc.collect()
staging = bytearray(SIZE)
matrix = rgbmatrix.RGBMatrix(width=WIDTH, height=HEIGHT,
    bit_depth=int(os.getenv('TICKER_BIT_DEPTH', 2)),
    rgb_pins=[board.GP8, board.GP9, board.GP10, board.GP11, board.GP12, board.GP13],
    addr_pins=[board.GP15, board.GP16, board.GP17, board.GP18],
    clock_pin=board.GP14, latch_pin=board.GP19, output_enable_pin=board.GP20,
    framebuffer=fb, doublebuffer=False)
buttons = []
for pin in (board.GP2, board.GP3, board.GP4, board.GP5):
    b = digitalio.DigitalInOut(pin)
    b.switch_to_input(pull=digitalio.Pull.UP)
    buttons.append(b)
# Minimal debouncer. Release actions distinguish tap and hold.
raw = [True] * 4
stable = [True] * 4
changed = [0.0] * 4
pressed = [0.0] * 4
sport, rev, favorite = 'NBA', '', False
page, pages, interval = 0, 1, 12
session = None
next_request = 0.0
last_ok = None
retry = 3
stale_marked = False
auto_advance = False

def mark_offline():
    # Native (x=0,y=31) maps to left sidebar top-left for CW, bottom-right CCW.
    # A visible red corner indicator supplements the retained frame.
    for y in (0, 1, 30, 31):
        for x in (0, 1, 62, 63):
            fb[y * WIDTH + x] = 0xf800
    matrix.refresh()

def request_frame():
    global session, rev, sport, favorite, page, pages, interval
    if not wifi.radio.connected:
        session = None
        wifi.radio.connect(SSID, PASSWORD, timeout=12)
    if session is None:
        session = adafruit_requests.Session(socketpool.SocketPool(wifi.radio), ssl.create_default_context())
    url = URL + '/api/frame?sport=' + sport + '&rev=' + rev + '&fav=' + ('1' if favorite else '0') + '&page=' + str(page)
    response = None
    try:
        response = session.get(url, headers={'Authorization':'Bearer '+TOKEN, 'Accept-Encoding':'identity'}, stream=True, timeout=10)
        h = {k.lower():v for k,v in response.headers.items()}
        if response.status_code != 200 or h.get('x-ticker-protocol') != '1':
            raise ValueError('Invalid HTTP response: '+str(response.status_code))
        nr = h.get('x-ticker-revision','')
        ns = h.get('x-ticker-sport','')
        nf = h.get('x-ticker-favorite','')
        np = int(h['x-ticker-page']); nps = int(h['x-ticker-pages']); ni = int(h['x-ticker-rotation'])
        if len(nr)!=16 or any(c not in '0123456789abcdef' for c in nr) or ns not in ('NBA','NFL','MLB') or nf not in ('0','1') or not (0<=np<nps<=100 and 5<=ni<=60):
            raise ValueError('Invalid frame metadata')
        pos = 0
        for chunk in response.iter_content(chunk_size=512):
            if pos + len(chunk) > SIZE:
                raise ValueError('Oversized frame')
            staging[pos:pos+len(chunk)] = chunk
            pos += len(chunk)
        if pos != SIZE:
            raise ValueError('Truncated frame')
        for i in range(WIDTH * HEIGHT):
            fb[i] = staging[i*2] | (staging[i*2+1] << 8)
        matrix.refresh()
        rev, sport, favorite, page, pages, interval = nr, ns, nf=='1', np, nps, ni
    finally:
        if response is not None:
            response.close()
        gc.collect()

print('Dallas ticker v1; free heap:', gc.mem_free())
while True:
    now = time.monotonic()
    for i,b in enumerate(buttons):
        v = b.value
        if v != raw[i]:
            raw[i], changed[i] = v, now
        if v != stable[i] and now-changed[i] >= .035:
            stable[i] = v
            if not v:
                pressed[i] = now
            else:
                held = now-pressed[i] >= .8
                if i < 3:
                    sport = ('NBA','NFL','MLB')[i]
                    favorite = held
                    page = 0
                elif not held:
                    page = (page+1)%pages
                next_request = 0
                auto_advance = False
    if now >= next_request:
        if auto_advance:
            page = (page+1)%pages
            auto_advance = False
        try:
            request_frame()
            last_ok = time.monotonic()
            stale_marked = False
            retry = 3
            next_request = last_ok + interval
            print('Frame', sport, page+1, '/', pages, 'heap', gc.mem_free())
            auto_advance = True
        except (OSError, ValueError, RuntimeError, MemoryError, KeyError) as e:
            print('Frame error:', e)
            session = None
            gc.collect()
            if not stale_marked:
                mark_offline()
                stale_marked = True
            next_request = time.monotonic() + retry
            retry = min(60,retry*2)
    time.sleep(.02)
