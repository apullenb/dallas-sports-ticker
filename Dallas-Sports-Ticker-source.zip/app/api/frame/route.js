import {frameHandler} from '../../../lib/service.mjs';
export const runtime='nodejs';
export async function GET(request){return frameHandler(request);}
