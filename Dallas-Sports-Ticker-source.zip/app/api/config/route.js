import {configHandler} from '../../../lib/service.mjs';
export const runtime='nodejs';
export const dynamic='force-dynamic';
export async function GET(request){return configHandler(request);}
export async function PUT(request){return configHandler(request);}
