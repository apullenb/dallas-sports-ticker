import {previewHandler} from '../../../lib/service.mjs';
export const runtime='nodejs';
export async function POST(request){return previewHandler(request);}
