import './globals.css';
export const metadata={title:'Dallas Sports Ticker | Control room',description:'Control and preview your three-panel LED scoreboard'};
export default function RootLayout({children}){return <html lang="en"><body>{children}</body></html>;}
