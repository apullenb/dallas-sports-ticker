# Dallas Sports Ticker — Next.js / Pico W (v0.1)

A server-rendered RGB565 scoreboard and control dashboard for the **three panels already ordered**, using the selected Dallas skyline enclosure concept. The web app runs on Vercel, not on the Pico. The Pico is a thin Wi-Fi display client. Future interface changes require only a web deployment, not a USB connection.

## Quick start

Requirements: Node.js 22+, npm. The initial dashboard uses labeled synthetic scores, with no account or API key needed to view demo mode.

```sh
npm install
npm test
npm run dev
# Open http://localhost:3000
```

To build: `npm run build` then `npm start`. A production build has not yet been run in the authoring environment because DNS/network access to npm was unavailable. Next/React dependencies are declared but not vendored; generate and commit the lockfile on first install. CI is supplied to run the tests and full build on GitHub. No repository or Vercel deployment has been created.

## Deploy to Vercel

1. Create a GitHub repository, put the contents of this folder in its root, commit and push. Import it into Vercel as a Next.js project (Node 22+). Do not commit secrets or `firmware/settings.toml`.
2. In Vercel project environment variables, set `ADMIN_TOKEN` and `DEVICE_TOKEN` to different randomly generated high-entropy values (e.g. `openssl rand -hex 32` twice). Tokens are checked in server routes, and neither is embedded in the client build. In local development only, requests are accepted without a token when the respective environment variable is absent. In production, unset tokens fail closed.
3. If you want dashboard publishing **without redeploying**, connect an Upstash Redis database and supply `UPSTASH_REDIS_REST_URL` and `UPSTASH_REDIS_REST_TOKEN`. These are server-only credentials. Redis is optional; without it, dashboard preview and exporting deployment defaults still work, but the publish route returns 409 rather than pretending to persist settings.
4. Deploy. Use the stable production HTTPS domain, not a protected preview URL; device requests must not be redirected to an interactive login screen.
5. Open the dashboard. Enter the admin token, load settings, switch ESPN mode to test real score and logo data, then publish if Redis is configured. Without Redis, export `defaults.json`, replace `lib/defaults.json`, and redeploy. If Redis is configured, published settings override defaults; renderer source changes still take effect automatically on deploy.
6. Test the device endpoint (replace placeholders):

```sh
curl --fail --show-error -D frame.headers -o frame.bin \
  -H "Authorization: Bearer $DEVICE_TOKEN" \
  https://YOUR-PROJECT.vercel.app/api/frame
wc -c frame.bin  # must be 12288
```

The initial `X-Ticker-Revision` response identifies the active configuration. Use it on subsequent requests to select sport and page. For example: `/api/frame?rev=REVISION&sport=MLB&fav=0&page=1`.

## Dashboard

- NBA, NFL, MLB selector; Dallas-only filter; logo toggle; brightness and page interval; clockwise/counterclockwise mounting setting.
- Split view: two live games above and two scheduled/completed games below, when available. Each group cycles independently if page counts differ. League view: up to four live games, or daily games if none live. Featured: one larger Dallas-prioritized game above; two other games below; featured status on the sidebar.
- Team colors, tiny logos on both competitors, game status and clock/inning, league icon, selected-league counts and page indicator. Actual pixel budget is 3×5 lettering for compact mode; it is not equivalent to the higher-resolution concept photograph. Demo mode uses colored monogram icons, not actual team logos. Live logos are fetched from ESPN and reduced by Sharp to 8×8 or 12×12; failures fall back to monograms. Small real logos may not be recognizable from across the room. The dashboard has a proportional stylized enclosure, not a photorealistic rendering.
- Simulator and device use `lib/render.mjs`. The browser displays the same RGB565 values, but real color output depends on bit depth, panel electronics and viewing distance. Very low brightness settings may appear dark/black at bit depth 2; test brightness and bit depth on the actual chain.
- Preview uses the current dashboard settings; the device uses the last published or deployed settings. Browser previews do not silently modify the ticker.

## Data and caching

`lib/sports.mjs` targets ESPN's unofficial `site.api.espn.com/apis/site/v2/sports/{sport}/{league}/scoreboard?dates=YYYYMMDD&limit=100`. NBA, NFL and MLB supported. Events are filtered to the requested date in America/Chicago, deduplicated, normalized and sorted with Dallas first. An event that started the previous Central day is excluded, even if still underway after midnight; this daily-view rule can be revised server-side. ESPN availability and coverage are not guaranteed. Date-specific queries could not be verified against the live server from this sandbox; confirm on deployment. No fallback to fabricated scores for device requests: upstream failures return HTTP 503. Browser demo is explicitly labeled; unsuccessful live preview does not make demo scores live. Logo allowlist accepts HTTPS PNGs from ESPN's team-logo path only; redirects are refused. Images are downloaded/decoded server-side, never by the Pico. Team assets are third-party intellectual property; personal hobby use is assumed, not a license to redistribute commercially.

Next fetch revalidation is targeted at 60 seconds for scores and 24 hours for raw logos. Revalidation is demand-driven, not a guaranteed timer; ESPN's own latency and Vercel cache behavior must be measured in deployment. This first version requests one complete frame per page interval (default 12 seconds), not one HTTP call per LED refresh. It retains the last successful frame during network failure, with red corner indicators. Page rotation pauses until network recovery. Server performs all layout/rendering. No server-generated animation strips, countdown timer, device telemetry, custom OTA firmware updater, scrolling pixel animation, or offline multi-page cache yet. Those are separate next-stage features. Physical button polling may miss quick presses while a network request is blocking; test real timing before installation.

## Frame protocol v1

`GET /api/frame` requires `Authorization: Bearer <DEVICE_TOKEN>` in production. Response is exactly 12,288 bytes, no JSON or base64, packed RGB565 little-endian, row-major 192×32. First 64 columns map to P4 native coordinates, second to upper P2.5, third to lower P2.5. Physical rotation mapped by renderer: CW native `(y,31-x)`, CCW `(63-y,x)`. Header fields:

| Header | Meaning |
|---|---|
| X-Ticker-Protocol | `1` |
| X-Ticker-Revision | 16 hex characters; changes when settings change |
| X-Ticker-Sport | NBA / NFL / MLB |
| X-Ticker-Favorite | 0 / 1 |
| X-Ticker-Page | zero-based page |
| X-Ticker-Pages | number of available pages |
| X-Ticker-Rotation | interval in seconds (not angle) |

Config changes reset device sport/favorite selection to published defaults on revision mismatch; otherwise physical buttons override those two settings locally. Interface/layout code deployed on the server does not require a device firmware update. New protocol, GPIO mapping, networking logic or low-level driver changes still require firmware changes; application OTA is not implemented in v1.

Other endpoints: `POST /api/preview` (admin token, `{config,page,demo}`; returns base64 of identical frame + preview metadata), `GET /api/config` (admin token), `PUT /api/config` (admin token + config JSON; persists in Redis). Single-device scope. For public deployment, use rate limiting and monitor cost/usage; preview/config endpoints require admin authentication and device endpoint uses separate secret.

## Hardware / firmware

- Raspberry Pi Pico W, CircuitPython (install current supported Pico W UF2; back up existing MicroPython project before changing firmware). The Pico is not a Raspberry Pi Linux computer. Install matching Adafruit CircuitPython Requests library `adafruit_requests.mpy` in `CIRCUITPY/lib/` (plus any dependencies identified by the chosen bundle). Copy `firmware/code.py` to root of CIRCUITPY and copy `firmware/settings.example.toml` as `settings.toml`; fill in Wi-Fi, stable HTTPS deployment URL, device token. The device uses CircuitPython native `rgbmatrix`, `wifi`, `socketpool`, `ssl` and a staged frame buffer. Verify TLS trust for deployed domain; do not disable certificate validation. The initial bit depth 2 is conservative; it provides 64 output colors and reduces memory. Test memory, TLS, color, refresh and stability before raising bit depth.
- P4 (rotated vertical) 128×256 mm, 32×64 logical pixels; two P2.5 160×80 mm, 64×32 each. All native 64×32, HUB75, documented 1/16 scan. Mixed-model chain operation is **not** yet hardware-tested.
- Signal wiring matches previous test bench: R1/G1/B1/R2/G2/B2 = GP8–13, CLK GP14, A/B/C/D = GP15–18, LAT GP19, OE GP20. Use two AHCT245 5V level-shifters and decoupling, shared ground, verified panel pinouts, and OUT-to-IN cables P4 → upper P2.5 → lower P2.5. Physical chain order may require reversal/remapping after a directional diagnostic; do not assume orientation from the Amazon image. Buttons GP2/3/4/5 to GND with pullups. Tap NBA/NFL/MLB for league; hold for Dallas-only; NEXT tap advances, hold requests current page again. On first boot, server defaults take precedence until revision received.
- Panel rated total 9A at 5V (4A + 2.5A + 2.5A); previously specified regulated external 5V/15A supply, rated distribution and fused branches, not through breadboard/Pico. Pico powered via separate USB for tests, shared GND. Verify voltage and wiring before energizing, keep mains supply external and accessible, provide ventilation. Follow manufacturer pinouts and bench test one panel, then identical pair, then mixed chain.

Reference documentation:
- https://docs.waveshare.com/RGB-Matrix-Px-64x32
- https://circuitpython.org/board/raspberry_pi_pico_w/
- https://docs.circuitpython.org/en/stable/shared-bindings/rgbmatrix/
- https://docs.circuitpython.org/projects/requests/en/latest/api.html
- https://nextjs.org/docs/app/getting-started/route-handlers
- https://nextjs.org/docs/app/api-reference/functions/fetch
- https://upstash.com/docs/redis/features/restapi

## Test evidence and next checks

`npm test` executed successfully in Node 22 using the preinstalled Sharp library (16 tests, including 720 renderer permutations). Actual PNG conversion used a synthetic PNG; ESPN/Redis calls were mocked. Both JSX files transpiled with TypeScript and firmware parsed with CPython. Neither Next production build nor browser dashboard runtime nor actual Vercel deployment nor real Pico execution was verified. See `TEST-RESULTS.txt`.

Before permanent mount: run GitHub CI, deploy, confirm date-specific live API results for each league, inspect rendered actual logo assets, verify binary length and auth, test Pico with one panel then all three, confirm chain order / orientation / RGB colors, observe heap usage and network reconnects, and run a sustained refresh test. No new controller is assumed. Hardware still requires physical validation.
